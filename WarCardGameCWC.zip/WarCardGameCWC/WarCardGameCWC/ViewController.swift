//
//  ViewController.swift
//  WarCardGameCWC
//
//  Created by Bane Manojlovic on 01/07/2020.
//  Copyright © 2020 Bane Manojlovic. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    // MARK: - Outlets
    @IBOutlet weak var leftImageView: UIImageView!
    @IBOutlet weak var rightImageView: UIImageView!
    @IBOutlet weak var leftScoreLabel: UILabel!
    @IBOutlet weak var rightScoreLabel: UILabel!
    @IBOutlet weak var ressetButton: UIButton!
    @IBOutlet weak var closeButton: UIButton!
    
    // MARK: - Properties
    var leftScore = 0
    var rightScore = 0
    
    // MARK: - Lifecycle methods
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }

    // MARK: - Action methods
    @IBAction func dealButtonTapped(_ sender: Any) {

        let leftNumber = Int.random(in: 2...14)
        let rightNumber = Int.random(in: 2...14)

        leftImageView.image = UIImage(named: "card\(leftNumber)")
        rightImageView.image = UIImage(named: "card\(rightNumber)")
        
        giveWinner(leftNumber, rightNumber)
    }
    
    @IBAction func ressetTapped(_ sender: Any) {
        leftImageView.image = UIImage(named: "card\(14)")
        rightImageView.image = UIImage(named: "card\(14)")
        leftScore = 0
        rightScore = 0
        leftScoreLabel.text = String(0)
        rightScoreLabel.text = String(0)
    }
    
    @IBAction func closeTapped(_ sender: Any) {
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
            UIApplication.shared.perform(#selector(NSXPCConnection.suspend))
             DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
              exit(0)
             }
        }
    }

    private func giveWinner(_ left: Int, _ right: Int) {
        if left > right {
            // player wins
            leftScore += 1
            leftScoreLabel.text = String(leftScore)
        } else if left < right {
            // cpu wins
            rightScore += 1
            rightScoreLabel.text = String(rightScore)
        } else {
            // tie
        }
    }
    
}

